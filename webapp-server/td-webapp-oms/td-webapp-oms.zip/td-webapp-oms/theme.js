module.exports = () => {
  return {
    // support 0B8DE5 29A176 455EC5 6539B4 F06292 (refer to: .asider-logo in IndexPage.less)
    '@primary-color': '#0B8DE5',
    '@link-color': '#0B8DE5',
    '@border-radius-base': '2px',
  };
};
