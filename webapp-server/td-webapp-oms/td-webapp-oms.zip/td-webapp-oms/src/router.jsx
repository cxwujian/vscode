import React from 'react';
import { Router, Route, IndexRedirect } from 'dva/router';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import Error401 from './components/common/Error401';
import Error404 from './components/common/Error404';
import IndexPage from './routes/IndexPage';

// set nprogress theme color style
const npColor = '#fff';
const bgStyle = `style="background:${npColor}"`;
const spStyle = `style="border-top-color:${npColor};border-left-color:${npColor}"`;
const pegStyle = `style="box-shadow:0 0 10px ${npColor}, 0 0 5px ${npColor}"`;
const temp = `<div class="bar" ${bgStyle} role="bar"><div class="peg" ${pegStyle}></div></div><div class="spinner" role="spinner"><div class="spinner-icon" ${spStyle}></div></div>`;
NProgress.configure({ template: temp });

export default function ({ history, app }) {
  // 校验url地址权限 path首字母去掉'/'(如果有)
  const checkAuth = (items, path) => {
    let pass = false;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.children && item.children.length > 0) {
        pass = checkAuth(item.children, path.charAt(0) === '/' ? path.substr(1) : path);
        if (pass === true) { break; }
      } else if (item.to === path) {
        pass = true; break;
      }
    }
    return pass;
  }

  const handleEnter = (nextState, replace, next) => {
    const path = nextState.location.pathname;                // 当前地址
    const auth = app._store.getState().indexPage.menuItems;  // 所有菜单
    const pass = checkAuth(auth, path.charAt(0) === '/' ? path.substr(1) : path);  // 权限校验结果
    if (pass === false) {
      replace('/error/401'); next();
    } else {
      next();
    }
  }

  const loadStart = () => {
    NProgress.inc();
  }

  const loadEnd = () => {
    NProgress.done();
  }

  // 动态加载页面
  const Home = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/Home.jsx'));
      loadEnd();
    }, 'Home');
  };
  // oms routers
  const summaryOrderManage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/SummaryOrderManage'));
      loadEnd();
    }, 'summaryOrderManage');
  }
  const summaryHisOrderManage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/SummaryHisOrderManage'));
      loadEnd();
    }, 'summaryHisOrderManage');
  }
  const bankcardOrderManage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/BankcardOrderManage'));
      loadEnd();
    }, 'bankcardOrderManage');
  }
  const bankcardHisOrderManage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/BankcardHisOrderManage'));
      loadEnd();
    }, 'bankcardHisOrderManage');
  }
  const scanOrderManage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/ScanOrderManage'));
      loadEnd();
    }, 'scanOrderManage');
  }
  const scanHisOrderManage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/ScanHisOrderManage'));
      loadEnd();
    }, 'scanHisOrderManage');
  }
  const orderTransRecmanage = (location, callback) => {
    loadStart();
    require.ensure([], (require) => {
      callback(null, require('./routes/oms/orderManage/OrderTransRecmanage'));
      loadEnd();
    }, 'orderTransRecmanage');
  }


  return (
    <Router history={history}>
      <Route path="/" component={IndexPage}>
        <IndexRedirect to="home" />
        <Route path="/home" getComponent={Home} />
        <Route path="/oms/orderManage/summaryOrderManage" getComponent={summaryOrderManage} onEnter={handleEnter} />
        <Route path="/oms/orderManage/summaryHisOrderManage" getComponent={summaryHisOrderManage} onEnter={handleEnter} />
        <Route path="/oms/orderManage/bankcardOrderManage" getComponent={bankcardOrderManage} onEnter={handleEnter} />
        <Route path="/oms/orderManage/bankcardHisOrderManage" getComponent={bankcardHisOrderManage} onEnter={handleEnter} />
        <Route path="/oms/orderManage/scanOrderManage" getComponent={scanOrderManage} onEnter={handleEnter} />
        <Route path="/oms/orderManage/scanHisOrderManage" getComponent={scanHisOrderManage} onEnter={handleEnter} />
        <Route path="/oms/orderManage/orderTransRecmanage" getComponent={orderTransRecmanage} onEnter={handleEnter} />
        <Route path="/error/401" component={Error401} />
        <Route path="*" component={Error404} />
      </Route>
    </Router>
  );
}
