export default {
  namespace: 'home',
  state: {
  },
}
